const valida = document.getElementById("valida");


function validacnpj() {
      var cnpj = document.getElementById("cnpj");
      var soma = 0;

      var x = 0;
      var y = 5;
      var dig1 = 0;
      var dig2 = 0;
      
      //Cálculo do segundo digito
      for (x = 0; x < 12; x++) {
          soma += cnpj.value[x] * y;
          y--;
          if (y==1) {
              y = 9;
          }   
      }
      dig1 = soma % 11;

      if (dig1 < 2) {
            dig1 = 0;
      } else {
            dig1 = 11 - dig1;
      }
      

      //Cálculo do segundo digito
      var soma = 0;
      var y = 6;
      for (x = 0; x < 13; x++) {
          soma += cnpj.value[x] * y;
          y--;
          if (y==1) {
              y = 9;
          }
          
      }
      dig2 = soma % 11;

      if (dig2 < 2) {
            dig2 = 0;
      } else {
            dig2 = 11 - dig2;
      }

      // resposta
      if (cnpj.value[12] + cnpj.value[13] == dig1 + "" + dig2) {
            alert("CNPJ é válido")
      } else {
            alert("CNPJ é inválido")
      }
}
valida.addEventListener("click", validacnpj);
