const valida = document.getElementById("valida");


function validacpf() {
    var cpf = document.getElementById("cpf");
    var soma = 0;
    var x = 0;
    var y = 10;
    var dig1 = 0;
    var dig2 = 0;
    for (x = 0; x < 9; x++) {
        soma += cpf.value[x] * y;
        y--;

    }
    dig1 = (soma * 10) % 11;
    if (dig1 == 10) {
        dig1 = 0;
    }
  

    // Calculo do segundo digito
    soma = 0;
    y = 11;
    for (x = 0; x < 10; x++) {
        soma += cpf.value[x] * y;
        y--;
    }    
    dig2 = (soma * 10) % 11 ;
    if (dig2 == 10) {
        dig2 = 0;
    }
    

    if (cpf.value[9] + cpf.value[10] == dig1 + "" + dig2) {
        alert("CPF é válido.");
    } else {
        alert("CPF é inválido.")
    }


}

valida.addEventListener("click", validacpf);