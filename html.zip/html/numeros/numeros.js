const valida = document.getElementById("valida");
const numero1 = document.getElementById("numero1");
const soma = document.getElementById("soma");



function calcular() {
    var numero = document.getElementById("numero");
   
    // somar os 10 números
    var tsoma = 0;
    var x = 0;
    for (x = 0; x <= 9; x++) {
        tsoma += parseInt(numero.value[x]);
    }    
    soma.textContent = "Soma dos 10: " + tsoma;
    

    // informar quantidade de números 1 digitados
    var conta1 = 0;
    for (x = 0; x <= 9; x++) {
        if(parseInt(numero.value[x]) == 1) {
            conta1++;
        }
    }
    numero1.textContent = conta1;

    // mostrar o número ao contrario
    var y = "";
    for (x = 9; x >= 0; x--) {
        y += numero.value[x];
    }    
    alert(y);
    

}

valida.addEventListener("click", calcular);