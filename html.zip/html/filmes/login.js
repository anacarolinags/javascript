const logar = document.getElementById("logar");

function startlog() {
    var email = document.getElementById("email");
    var senha = document.getElementById("senha");

    // if (email.value == 'ana@vinil.com' && senha.value == "123") {
        // window.location.href = "portal.html";
    // }
    // else {
        // alert("Usuário ou senha inválidos:");
    // }

    if (email.value == 'ana@filmes.com' && senha.value == "123") {
        window.location.href = "portal.html";
    } else if (email.value != 'ana@filmes.com') {
        alert("Usuário inválido");
    } else if (senha.value != "123") {
        alert("Senha Inválida");
    } 
}   

    

logar.addEventListener("click", startlog);