const cadastrar = document.getElementById("Cadastrar")

function cadastrarf(params) {
    var data = document.getElementById("data");
    var dia = parseInt(data.value[0] + data.value[1]);
    var mes = parseInt(data.value[3] + data.value[4]); 
    var ano = parseInt(data.value[6] + data.value[7] + data.value[8] + data.value[9]); 
    
    // Inicio Validação de Data
    // Validar dias
    if (dia < 1 || dia > 31) {
        alert("Dia Inválido");
    }

    // Validar meses
    if (mes < 1 || mes > 12) {
        alert("Mês Inválido");
    }
      
    // Só aceitar anos a partir de 1900
    if (ano < 1900) {
        alert("Ano deve ser maior que 1900");
    }

    // Não aceitar 31 nos meses abaixo
    if (dia == 31 && (mes == 2 || mes == 4 || mes == 6 || mes == 9 || mes ==11)) {
        alert("Dia 31 inválido para mês informado");
    }

    // Não aceitar dia 30 em fevereiro
    if (dia == 30 && mes == 2) {
        alert("Dia 30 inválido para o mês de fevereiro")
    }

    // Encontrar ano bissexto
    var fator1 = ano % 4;
    var fator2 = ano % 100;
    var fator3 = ano % 400;
    bissexto = 0;
    if (fator1 == 0 && fator2 != 0 || fator3 == 0 ) {
        bissexto = 1;
    }

    // Verificar 29/02 em ano bissexto
    if (dia==29 && mes == 2 && bissexto == 0) {
        alert("Dia 29/02 Inválido. Não é ano Bissexto");
    }
    // Fim Validação de Data


}


cadastrar.addEventListener("click", cadastrarf)