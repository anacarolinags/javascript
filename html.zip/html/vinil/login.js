const logar = document.getElementById("logar");

function startlog() {
    var email = document.getElementById("email");
    var senha = document.getElementById("senha");

    if (email.value == 'ana@vinil.com' && senha.value == "123") {
        window.location.href = "portal.html";
    }
    else {
        alert("Usuário ou senha inválidos:");
    }

}

logar.addEventListener("click", startlog);